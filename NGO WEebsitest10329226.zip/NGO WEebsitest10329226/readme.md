this file shows how to use the website
it consists of 6 pages
each page heading is self explanatory.
the other attachements are -
Name and student number 
Essay
Table of contents
website assets 
Reference Page 